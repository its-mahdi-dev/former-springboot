package com.example.former;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormerApplication {

    public static void main(String[] args) {
        SpringApplication.run(FormerApplication.class, args);
    }

}
