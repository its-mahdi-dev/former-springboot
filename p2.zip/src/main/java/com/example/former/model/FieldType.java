package com.example.former.model;

public enum FieldType {
    TEXT,
    NUMBER,
    BOOLEAN,
    DATE
}
