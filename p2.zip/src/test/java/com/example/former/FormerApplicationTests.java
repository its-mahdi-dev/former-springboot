package com.example.former;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormerApplicationTests {

    @Test
    void contextLoads() {
    }

}
